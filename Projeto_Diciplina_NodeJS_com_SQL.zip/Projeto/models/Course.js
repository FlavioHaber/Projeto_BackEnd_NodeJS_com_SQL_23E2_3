const { Sequelize, DataTypes } = require('sequelize')

const db = require('../database/conn')

const Course = db.define('Course',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    Description: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    dateStart: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    dateTermination: {
        type: DataTypes.DATEONLY
    },
    qtdRegistration: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
})

module.exports = Course