const { Sequelize, DataTypes } = require('sequelize')

const db = require('../database/conn')

const Student = require('./Student')
const Course = require('./Course')

const Registration = db.define('Registration',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    dateRegistration: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    dateCancel: {
        type: DataTypes.DATEONLY,
        allowNull: true,
    },
    // studentId: {
    // type: DataTypes.INTEGER,
    // allowNull: false,
    // },
    // courseId: {
    // type: DataTypes.INTEGER,
    // allowNull: false,
    // }
})

Registration.belongsTo(Student)
Registration.belongsTo(Course)

module.exports = Registration