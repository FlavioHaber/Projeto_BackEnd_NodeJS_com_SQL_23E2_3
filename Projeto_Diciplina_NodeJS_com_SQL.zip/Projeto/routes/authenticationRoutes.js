const express = require('express')
const router = express.Router()

const authenticationController = require('../controllers/authenticationController')

router.post('/', authenticationController.login)

router.get('/', authenticationController.logout)

router.post('/refresfhToken', authenticationController.refreshToken)

module.exports = router