const express = require('express')
const router = express.Router()

const studentsController = require('../controllers/studentsController')

const { VerifyJWT } = require('../tokenValidation')

router.get('/', VerifyJWT, studentsController.getStudents)

router.post('/addLogin', studentsController.addStudent)

router.post('/', VerifyJWT,studentsController.addStudent)

router.put('/:id', VerifyJWT, studentsController.changeStudent)

router.delete('/:id', VerifyJWT, studentsController.deleteStudent)

module.exports = router