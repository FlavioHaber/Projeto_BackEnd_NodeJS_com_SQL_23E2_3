const express = require('express')
const router = express.Router()

const registrationController = require('../controllers/registrationController')

router.get('/', registrationController.getRegistration)

router.post('/', registrationController.addRegistration)

router.delete('/:id', registrationController.deleteRegistration)

module.exports = router