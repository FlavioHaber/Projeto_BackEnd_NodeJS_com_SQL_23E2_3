const express = require('express')
const jwt = require('jsonwebtoken')

function VerifyJWT(req, res, next) {
    const token = req.body.token || req.query.token
    const reftoken = req.body.reftoken || req.query.reftoken

    if(!token){
        return res.status(403).json({auth: false, message: 'No token provided'})
    }

    jwt.verify(token, 'secret_key', (err, student)=>{
        if (err) {
            if (reftoken) {
                jwt.verify(reftoken, 'secret_key2', (err2, student2)=> {
                    if(err2) {
                        return res.status(403).json({auth: false, message: 'Invalid refresh token'})
                    }
                    const newtoken = jwt.sign({id: student2.id, username: student2.username},'secret_key')
                    req.student = student2
                })
            } else {
                return res.status(403).json({auth: false, message: 'Access token expired'})
            }
         } else {
             req.student = student
             next()
        }
    })
}

module.exports = {VerifyJWT}

