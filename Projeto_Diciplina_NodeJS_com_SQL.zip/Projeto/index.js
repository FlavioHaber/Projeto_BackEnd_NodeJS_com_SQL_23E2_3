const express = require('express')
const conn = require('./database/conn')

const {VerifyJWT} = require('./tokenValidation')

const app = express()

const studentsRoutes = require('./routes/studentRoutes')
const courseRoutes = require('./routes/courseRoutes')
const registrationRoutes = require('./routes/registrationRoutes')
const authenticationRoutes = require('./routes/authenticationRoutes')

app.use(
    express.urlencoded({
        extended:true
    })
)
app.use(express.json())

app.use('/students',  studentsRoutes)
app.use('/course', VerifyJWT, courseRoutes)
app.use('/registration', VerifyJWT, registrationRoutes)

app.use('/login', authenticationRoutes)
app.use('/logout', authenticationRoutes)

conn.sync({force: true})
    .then(() => {
        console.log('Sync OK')
        app.listen(3334, () => {
            console.log('Server starting')
        })
    })
    .catch((error) => {
        console.error('Error sync:', error);
    })
