const bcrypt = require('bcrypt')

const jwt = require('jsonwebtoken')

const Students = require('../models/Student')

class authenticationController {
    static async login(req, res) {
        try {
            const {username, password} = req.body

            const student = await Students.findOne({where:{username}})

            if(!student){
                return res.status(401).json({message:'Invalid username'})
            }

            const compareResult = await bcrypt.compare(password, student.password)

            if (!compareResult)
            {
                return res.status(401).json({message:'Invalid password'})
            }

            const token = jwt.sign({id:student.id, username:student.username},'secret_key')
            const reftoken = jwt.sign({id: student.id, username: student.username}, 'secret_key2')

            return res.status(200).json({message: 'Login OK',auth:true, token: token, refreshToken: reftoken})
        }
        catch (error) {
            console.error(error),
            res.status(500).json({message: 'Server Error'})
        }
    }

    static async logout(req, res) {
        return res.json({auth: false, token: null})
    }

    static async refreshToken(req, res) {
        const reftoken = req.body.refreshToken

        if (!reftoken) {
            return res.status(403).json({auth: false, message: 'No refresh token provided'})
        }

        jwt.verify(reftoken, 'secret_key2', (err, student) => {
            if (err) {
                return res.status(403).json({auth: false, message: 'Invalid refresh token'})
            }
            
            const newtoken = jwt.sign({id: student.id, username: student.username}, 'secret_key')

            res.json({refreshToken: newtoken})
        })
    }
}
module.exports = authenticationController