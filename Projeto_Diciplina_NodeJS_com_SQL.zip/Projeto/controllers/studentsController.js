const Students = require('../models/Student')
const Registration = require('../models/Registration')

const getStudents = async (req,res) => {
    try {
        const students = await Students.findAll()
        
        res.json(students)
    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const addStudent = async (req, res) => {
    try {
        const { name, address, city, state, age, phoneNumber, email, username, password } = req.body
        const student = await Students.create({
            name,
            address,
            city,
            state,
            age,
            phoneNumber,
            email,
            username,
            password
        });
        res.json(student)
    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const changeStudent = async (req,res)=>{
    try{
      const {id} = req.params
      const {name, address, city, state, age, phoneNumber, email, username, password} = req.body
      const student = await Students.findByPk(id)
  
      if(!student){
        return res.status(404).json({error: 'Student not found'})
      }
  
      student.name = name
      student.address = address
      student.city = city
      student.state = state
      student.age = age
      student.phoneNumber = phoneNumber
      student.email = email
      student.username = username
      student.password = password

      await student.save()
      res.json(student)
    }
    catch(error) {
      console.error(error)
      res.status(500).send('Server Error')
    }
}

const deleteStudent = async (req,res) => {
    try{
      const {id} = req.params
      const contStudent = await Registration.count({where: {studentId:id}})
  
      if(contStudent>0){
          return res.status(400).json({message:'Error delete student'})
      }
  
      const countStudent = await Students.destroy({where:{id}})
  
      if(countStudent===0)
      {
        return res.status(404).json({error: 'Student not found'})
      }
  
      res.json({message:'Student deleted'})
  
    }
    catch(error)
    {
      console.error(error)
      res.status(500).send('Server Error')
    }
}

module.exports={getStudents, addStudent, changeStudent, deleteStudent}
