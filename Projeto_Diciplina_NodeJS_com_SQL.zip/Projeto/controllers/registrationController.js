const Registration = require('../models/Registration')
const Students = require('../models/Student')
const Course = require('../models/Course')
const { Op } = require("sequelize");

const getRegistration = async (req,res) => {
    try {
        const registration = await Registration.findAll()

        res.json(registration)

    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const addRegistration = async (req,res) => {
    try {
        const { StudentId, CourseId, dateRegistration, dateCancel } = req.body 

        const student = await Students.findByPk(StudentId)
      
        if(!student){
          return res.status(404).json({error: 'Student not found'})
        }

        const course = await Course.findByPk(CourseId)
       
        if(!course){
          return res.status(404).json({error: 'Course not found'})
        }

        const registered = await Registration.findAll({where: {[Op.and]: [{ StudentId: StudentId }, { CourseId: CourseId }]}})

        if(registered){
            return res.status(404).json({error: 'Stundent already registred on course'})
          }

        const registration = await Registration.create({
            StudentId,
            CourseId,
            dateRegistration,
            dateCancel
        });

        course.increment('qtdRegistration')
        await course.save()

        res.json(registration)
    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const deleteRegistration = async (req, res) => {
    try{
        const {id} = req.params
    
        const registration = await Subscribe.findByPk(id)
    
        if(!registration)
        {
          return res.status(404).json({error: 'Registry not found'})
        }
    
        registration.dateCancel = new Date()

        const course = await Course.findByPk(registration.courseId)

        course.decrement('qtdRegistration')
  
        await registration.save()

        await course.save()
       
        res.json({message:'Enrolment calcelled'})
      }
      catch(error)
      {
        console.error(error)
        res.status(500).send('Server Error')
      }
}

module.exports = {getRegistration, addRegistration, deleteRegistration}
