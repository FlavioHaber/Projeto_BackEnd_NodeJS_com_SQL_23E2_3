const Course = require('../models/Course')
const Registration = require('../models/Registration')
const { Op } = require("sequelize");

const getCourse = async (req,res) => {
    try {
        const hoje = new Date()
        const course = await Course.findAll({where: { dateStart: { [Op.gt]: hoje}}})
        res.json(course)
    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const addCourse = async (req, res) => {
    try {
        const { Description, dateStart, dateTermination, qtdRegistration } = req.body 
        const course = await Course.create({
            Description,
            dateStart,
            dateTermination,
            qtdRegistration
        })
        res.json(course)
    } catch (error) {
        console.error(error)
        res.status(500).send('Server Error')
    }
}

const changeCourse = async (req, res) => {
    try{
        const {id} = req.params
        const {Description, dateStart, dateTermination, qtdRegistration} = req.body
        const course = await Course.findByPk(id)
    
        if(!course){
          return res.status(404).json({error: 'Course not found'})
        }
    
        course.Description = Description,
        course.dateStart = dateStart,
        course.dateTermination = dateTermination
        course.qtdRegistration = qtdRegistration
  
        await course.save()
        res.json(course)
      }
      catch(error) {
        console.error(error)
        res.status(500).send('Server Error')
      }
}

const deleteCourse = async (req, res) => {
    try{
        const {id} = req.params.id
 
        const contRegistration = await Registration.count({where: {courseId:id}})
    
        if(contRegistration>0){
            return res.status(400).json({message:'Error delete course'})
        }
    
        const countCourse = await Course.destroy({where:{id}})
    
        if(countCourse===0)
        {
          return res.status(404).json({error: 'Course not found'})
        }
    
        res.json({message:'Course deleted'})
    
      }
      catch(error)
      {
        console.error(error)
        res.status(500).send('Server Error')
      }
}

module.exports = {getCourse, addCourse, changeCourse, deleteCourse}
